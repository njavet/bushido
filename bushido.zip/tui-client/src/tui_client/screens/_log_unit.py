from typing import ClassVar, override

from rich.console import Group
from rich.panel import Panel
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.events import Key
from textual.message import Message
from textual.screen import ModalScreen
from textual.suggester import Suggester, SuggestionReady
from textual.widget import Widget
from textual.widgets import Input

from tui_client.api_client import BushidoApiClient
from tui_client.dtypes import UnitLogResult


class UnitSuggester(Suggester):
    def __init__(self, unit_names: list[str]) -> None:
        super().__init__()
        self.unit_names = unit_names

    @override
    async def get_suggestion(self, value: str) -> str | None:
        names = [name for name in self.unit_names if name.startswith(value)]
        if len(names) == 1:
            return names[0] + " "
        return None


class UnitInput(Input):
    def __init__(self, suggester: UnitSuggester) -> None:
        super().__init__(suggester=suggester, id="text_input")

    def on_suggestion_ready(self, event: SuggestionReady) -> None:
        self.action_delete_left_all()
        self.insert_text_at_cursor(event.suggestion)

    def on_key(self, event: Key) -> None:
        # workaround for accepting autocompletion
        if event.key == "space":
            self.action_cursor_right()
            event.stop()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self.post_message(UnitSubmitted(event.value.strip()))


class UnitSubmitted(Message):
    def __init__(self, value: str) -> None:
        super().__init__()
        self.value = value


class UnitHelpWidget(Widget):
    @override
    def render(self) -> Group:
        panels = []
        for item in ["yo"]:
            content = "\n".join([f"Grammar: {item}"])
            panel = Panel(content)
            panels.append(panel)
        return Group(*panels)


class LogUnitScreen(ModalScreen[UnitLogResult | None]):
    BINDINGS: ClassVar = [
        Binding("escape", "cancel", "cancel"),
    ]

    def __init__(self, api: BushidoApiClient, unit_names: list[str]) -> None:
        super().__init__()
        self.api = api
        self.unit_suggester = UnitSuggester(unit_names)

    async def action_cancel(self) -> None:
        await self.dismiss(None)

    @override
    def compose(self) -> ComposeResult:
        with Vertical(id="log_unit_dialog"):
            yield UnitHelpWidget()
            yield UnitInput(suggester=self.unit_suggester)

    async def on_unit_submitted(self, message: UnitSubmitted) -> None:
        if not message.value:
            self.app.notify("empty domain", title="logging failed", severity="error")
            return
        try:
            unit = await self.api.log_unit(line=message.value)
        except Exception as e:
            self.notify(str(e), title="logging failed", severity="error")
            return

        self.notify(
            f"logged unit: {unit.name}",
            title="logging successful",
            severity="information",
        )

        _ = self.dismiss(UnitLogResult(unit=unit))
