class UnitParsingError(Exception):
    pass
