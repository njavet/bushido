import datetime
import re

from bushidolib.constants import (
    COMPLETE_TIME_LEN,
    MILITARY_TIME_LEN,
    MINUTE_LEN,
    WEEK_START_DAY,
)
from bushidolib.exceptions import UnitParsingError


def time_string_to_seconds(time_string: str) -> float:
    """
    the input string can be of the form:
    MM:SS, HH:MM:SS, <num>h, <num>s, <num> (-> default is minutes)
    :param time_string:
    :return seconds:

    """
    if time_string is None:
        raise UnitParsingError("time_string is None")

    values = time_string.split(":")
    if len(values) > 1:
        return _colon_separated_time_string_to_seconds(values)

    try:
        m = float(values[0])
        return 60 * m
    except ValueError as e:
        if re.search(r"\d+h", values[0]):
            return 60 * 60 * float(values[0][:-1])
        if re.search(r"\d+s", values[0]):
            return float(values[0][:-1])
        raise UnitParsingError(f"unknown time format: {time_string}") from e


def _colon_separated_time_string_to_seconds(values: list[str]) -> float:
    # format HH:MM:SS
    if len(values) == COMPLETE_TIME_LEN:
        try:
            h = float(values[0])
            m = float(values[1])
            s = float(values[2])
        except ValueError as e:
            raise UnitParsingError("colon time format error") from e
        else:
            return h * 60 * 60 + m * 60 + s
    # format MM:SS
    elif len(values) == MINUTE_LEN:
        try:
            m = float(values[0])
            s = float(values[1])
        except ValueError as e:
            raise UnitParsingError("colon time format error") from e
        else:
            return m * 60 + s
    else:
        raise UnitParsingError("colon time format error")


def parse_military_time_string(time_string: str) -> datetime.time:
    # e.g. 1600 for 16:00
    if len(time_string) != MILITARY_TIME_LEN:
        raise UnitParsingError(f"incorrect military time {time_string}")
    try:
        hour = int(time_string[0:2])
        minutes = int(time_string[2:])
    except ValueError as e:
        raise UnitParsingError(f"incorrect military time {time_string}") from e
    else:
        return datetime.time(hour, minutes)


def parse_start_end_time_string(
    time_string: str,
) -> tuple[datetime.time, datetime.time]:
    """
        the format is HHMM-HHMM as start time and end time
        "normal case": 0400 <= start < end <= 2359
        TODO start is before midnight, end is after midnight

    :param time_string:
    :return:
    """
    reg = re.search("[0-2][0-9][0-5][0-9]-[0-2][0-9][0-5][0-9]", time_string)
    if reg is None:
        raise UnitParsingError("wrong time format")
    s, e = reg.group().split("-")

    start_t = parse_military_time_string(s)
    end_t = parse_military_time_string(e)
    return start_t, end_t


# TODO move to bushido package
def get_bushido_date_from_datetime(
    dt: datetime.datetime, tz: datetime.tzinfo, start_hour: int
) -> datetime.date:
    local_dt = dt.astimezone(tz)
    if 0 <= local_dt.hour < start_hour:
        return local_dt.date() - datetime.timedelta(days=1)
    return local_dt.date()


def find_previous_sunday(dt: datetime.date) -> datetime.date:
    """
    Finds the previous Sunday of the given date
    e.g., input: 01.01.2020
    returns: 29.12.2019

    """
    if dt.weekday() != WEEK_START_DAY:
        days = dt.weekday() + 1
        return dt - datetime.timedelta(days=days)
    return dt


def find_next_saturday(dt: datetime.date) -> datetime.date:
    if dt.weekday() != WEEK_START_DAY:
        days = 5 - dt.weekday()
        return dt + datetime.timedelta(days=days)
    return dt + datetime.timedelta(days=6)
